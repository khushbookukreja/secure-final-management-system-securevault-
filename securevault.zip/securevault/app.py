from flask import Flask, request, session, redirect, render_template
import sqlite3, bcrypt, pyotp, os, logging
from cryptography.fernet import Fernet

app = Flask(__name__)
app.secret_key = "supersecretkey"

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs("logs", exist_ok=True)

ADMIN_USER = "admin"
otp_store = {}

# ---------------- LOGGING ----------------
logging.basicConfig(
    filename="logs/security.log",
    level=logging.INFO,
    format="%(asctime)s - %(message)s"
)

# ---------------- ENCRYPTION ----------------
KEY_FILE = "secret.key"

def load_key():
    if not os.path.exists(KEY_FILE):
        key = Fernet.generate_key()
        open(KEY_FILE, "wb").write(key)
    return open(KEY_FILE, "rb").read()

cipher = Fernet(load_key())

# ---------------- DATABASE ----------------
def init_db():
    conn = sqlite3.connect("database.db")
    c = conn.cursor()

    c.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY,
        username TEXT UNIQUE,
        password BLOB
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS files(
        id INTEGER PRIMARY KEY,
        filename TEXT,
        owner TEXT
    )""")

    conn.commit()
    conn.close()

# ---------------- SECURITY ----------------
def safe_input(x): return x and len(x) <= 50
def bad_file(f): return f.lower().endswith((".exe",".bat",".sh"))

# ---------------- ROUTES ----------------
@app.route("/")
def home():
    return render_template("home.html")

@app.route("/register", methods=["POST"])
def register():
    u,p = request.form.get("username"), request.form.get("password")

    if not safe_input(u) or not safe_input(p):
        return "Invalid input"

    h = bcrypt.hashpw(p.encode(), bcrypt.gensalt())

    conn = sqlite3.connect("database.db")
    c = conn.cursor()

    try:
        c.execute("INSERT INTO users VALUES(NULL,?,?)",(u,h))
        conn.commit()
        return "Registered"
    except:
        return "User exists"

@app.route("/login", methods=["POST"])
def login():
    u,p = request.form.get("username"), request.form.get("password")

    conn = sqlite3.connect("database.db")
    c = conn.cursor()

    c.execute("SELECT password FROM users WHERE username=?",(u,))
    r = c.fetchone()
    conn.close()

    if r and bcrypt.checkpw(p.encode(), r[0]):
        otp = str(pyotp.random_base32())[:6]
        otp_store[u] = otp
        return f"""
        OTP: <b>{otp}</b>
        <form action='/verify' method='post'>
        <input name='username' value='{u}' hidden>
        <input name='otp'>
        <button>Verify</button></form>
        """
    return "Login failed"

@app.route("/verify", methods=["POST"])
def verify():
    u,o = request.form.get("username"), request.form.get("otp")
    if otp_store.get(u)==o:
        session["user"]=u
        return redirect("/dashboard")
    return "Wrong OTP"

@app.route("/dashboard")
def dashboard():
    if "user" not in session: return redirect("/")
    return render_template("dashboard.html",user=session["user"],admin=session["user"]==ADMIN_USER)

@app.route("/upload", methods=["POST"])
def upload():
    if "user" not in session: return redirect("/")

    f = request.files["file"]
    if bad_file(f.filename): return "Blocked file"

    name = f"{session['user']}_{f.filename}"
    path = os.path.join(UPLOAD_FOLDER,name)

    enc = cipher.encrypt(f.read())
    open(path,"wb").write(enc)

    conn=sqlite3.connect("database.db")
    c=conn.cursor()
    c.execute("INSERT INTO files VALUES(NULL,?,?)",(name,session["user"]))
    conn.commit()

    return "Uploaded"

@app.route("/files")
def files():
    if "user" not in session: return redirect("/")

    conn=sqlite3.connect("database.db")
    c=conn.cursor()

    if session["user"]==ADMIN_USER:
        c.execute("SELECT filename FROM files")
    else:
        c.execute("SELECT filename FROM files WHERE owner=?",(session["user"],))

    files=c.fetchall()

    data=[(f[0], os.path.getsize(os.path.join(UPLOAD_FOLDER,f[0]))) for f in files]

    return render_template("files.html",files=data)

@app.route("/view/<f>")
def view(f):
    if "user" not in session: return redirect("/")

    path=os.path.join(UPLOAD_FOLDER,f)
    dec=cipher.decrypt(open(path,"rb").read())

    return render_template("view.html",content=dec.decode(errors="ignore"))

@app.route("/logs")
def logs():
    if session.get("user")!=ADMIN_USER:
        return "Denied"
    return render_template("logs.html",logs=open("logs/security.log").read())

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

# ---------------- RUN ----------------
if __name__=="__main__":
    init_db()
    app.run(debug=True)